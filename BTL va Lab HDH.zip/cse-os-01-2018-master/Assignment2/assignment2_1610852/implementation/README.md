## How to run?

### Scheduling

```
make sched
make test_sched
```

### Memory Management

```
make mem
make test_mem
```


### Operating Systems

```
make os
make test_os
```

Also use

```
make
```
