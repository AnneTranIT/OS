#ifndef FIND_SUBSTR_H
#define FIND_SUBSTR_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int find_sub_string(const char *str, const char *sub);

#endif