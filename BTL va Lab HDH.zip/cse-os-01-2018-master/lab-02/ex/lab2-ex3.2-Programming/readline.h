#ifndef READ_LINE_H
#define READ_LINE_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int read_line(char *str);

#endif