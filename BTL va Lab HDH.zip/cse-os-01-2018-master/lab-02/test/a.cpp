#include <stdio.h>

int main(int narg, char * args) {
	
	printf("%d", narg);
	
	
	return 0;
}
