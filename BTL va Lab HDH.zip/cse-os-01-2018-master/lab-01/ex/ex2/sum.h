#ifndef SUM_CLASS
#define SUM_CLASS

int sum(int, int);

#endif