#ifndef SUB_CLASS
#define SUB_CLASS

int sub(int, int);

#endif