#ifndef MATHC_H_
#define MATHC_H_

int sum(int a, int b);

#endif // MATHC_H_
